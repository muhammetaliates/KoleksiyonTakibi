using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;


/**************************

**	SAKARYA �N�VERS�TES�
**	B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�

**	B�L���M S�STEMLER� M�HEND�SL��� B�L�M�

**	NESNEYE DAYALI PROGRAMLAMA DERS�
**	2019-2020 YAZ D�NEM�

**

**	PROJE NUMARASI.........: 01
**	��RENC� ADI............: MUHAMMET AL� ATE�		

**	��RENC� NUMARASI.......: B151200040

**	DERS�N ALINDI�I GRUP...: A

**************************/


namespace KoleksiyonTakibi
{
    static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new main());
        }
    }
}
